<?php

namespace App\Controllers;

use App\Models\HomeModel;

// Controlador principal para manejar las operaciones relacionadas con pacientes
class Home extends BaseController
{
    protected $homeModel;

    // Constructor que inicializa el modelo HomeModel
    public function __construct()
    {
        $this->homeModel = new HomeModel();
    }

    // Método para listar todos los pacientes
    public function index()
    {
        // Obtiene todos los registros de pacientes desde el modelo
        $data = $this->homeModel->getPacientes();

        // Devuelve los datos como una respuesta JSON con un mensaje
        return $this->response->setJSON(['mensaje' => 'Lista de Pacientes', 'data' => $data]);
    }

    // Método para insertar un nuevo paciente
    public function insertar()
    {
        // Obtiene los datos enviados en formato JSON desde la solicitud
        $input = $this->request->getJSON(true);

        // Llama al modelo para insertar el nuevo paciente y obtener su ID
        $id = $this->homeModel->insertPaciente($input);

        // Devuelve una respuesta JSON con un mensaje y el ID del paciente insertado
        return $this->response->setJSON(['mensaje' => 'Paciente insertado', 'ID' => $id]);
    }

    // Método para actualizar los datos de un paciente existente
    public function modificar($id)
    {
        // Obtiene los datos enviados en formato JSON desde la solicitud
        $input = $this->request->getJSON(true);

        // Llama al modelo para actualizar el paciente por su ID
        $updated = $this->homeModel->updatePaciente($id, $input);

        // Devuelve una respuesta JSON indicando si la actualización fue exitosa
        return $this->response->setJSON(['mensaje' => $updated ? 'Paciente actualizado' : 'No se pudo actualizar']);
    }

    // Método para eliminar un paciente
    public function eliminar($id)
    {
        // Llama al modelo para eliminar el paciente por su ID
        $deleted = $this->homeModel->deletePaciente($id);

        // Devuelve una respuesta JSON indicando si la eliminación fue exitosa
        return $this->response->setJSON(['mensaje' => $deleted ? 'Paciente eliminado' : 'No se pudo eliminar']);
    }
}

