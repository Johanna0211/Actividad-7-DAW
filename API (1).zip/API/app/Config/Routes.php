<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Define la ruta principal ("/") que apunta al método index del controlador Home
$routes->get('/', 'Home::index'); // Accede a la lista de pacientes

$routes->get('/pacientes', 'Home::index'); // Ruta GET para listar todos los pacientes

// Define la ruta para insertar un nuevo paciente, utilizando el método POST
$routes->post('/pacientes', 'Home::insertar'); 

// Define la ruta para modificar un paciente existente, utilizando el método PUT y el ID del paciente como parámetro
$routes->put('/pacientes/(:num)', 'Home::modificar/$1'); 

// Define la ruta para eliminar un paciente, utilizando el método DELETE y el ID del paciente como parámetro
$routes->delete('/pacientes/(:num)', 'Home::eliminar/$1'); 
