<?php

namespace App\Models;

use CodeIgniter\Model;

// Modelo para manejar las operaciones relacionadas con los pacientes en la base de datos
class HomeModel extends Model
{
    // Definición de la tabla en la base de datos que se utilizará
    protected $table = 'Pacientes'; // Cambiar según tu tabla principal

    // Definición de la clave primaria de la tabla
    protected $primaryKey = 'ID_Paciente'; // Clave primaria

    // Definición de los campos que pueden ser modificados mediante el modelo
    protected $allowedFields = ['Nombre', 'Apellido', 'Fecha_de_nacimiento', 'Telefono']; // Campos editables

    // Método para insertar un nuevo registro en la base de datos
    public function insertPaciente($data)
    {
        // Utiliza el método insert del modelo para agregar el nuevo paciente
        return $this->insert($data);
    }

    // Método para actualizar un registro existente en la base de datos
    public function updatePaciente($id, $data)
    {
        // Utiliza el método update del modelo para actualizar un paciente por su ID
        return $this->update($id, $data);
    }

    // Método para eliminar un registro en la base de datos
    public function deletePaciente($id)
    {
        // Utiliza el método delete del modelo para eliminar un paciente por su ID
        return $this->delete($id);
    }

    // Método para obtener todos los registros de pacientes de la base de datos
    public function getPacientes()
    {
        // Utiliza el método findAll para recuperar todos los pacientes
        return $this->findAll();
    }
}
